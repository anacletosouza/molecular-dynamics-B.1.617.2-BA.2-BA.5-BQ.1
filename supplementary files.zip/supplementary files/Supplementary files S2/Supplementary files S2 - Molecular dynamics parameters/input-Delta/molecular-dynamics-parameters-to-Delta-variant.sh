# Parameters and codes used in Molecular Dynamics Simulations using GROMACS 2022

#Especifications

#GROMACS version:    2022
#Precision:          mixed
#Memory model:       64 bit
#MPI library:        thread_mpi
#OpenMP support:     enabled (GMX_OPENMP_MAX_THREADS = 128)
#GPU support:        CUDA
#SIMD instructions:  AVX_256
#CPU FFT library:    fftw-3.3.8-sse2-avx-avx2-avx2_128
#GPU FFT library:    cuFFT
#RDTSCP usage:       enabled
#TNG support:        enabled
#Hwloc support:      disabled
#Tracing support:    disabled
#C compiler:         /opt/ohpc/pub/compiler/gcc/7.3.0/bin/gcc GNU 7.3.0
#C compiler flags:   -mavx -Wno-missing-field-initializers -fexcess-precision=fast -funroll-all-loops -O3 -DNDEBUG
#C++ compiler:       /opt/ohpc/pub/compiler/gcc/7.3.0/bin/g++ GNU 7.3.0
#C++ compiler flags: -mavx -Wno-missing-field-initializers -fexcess-precision=fast -funroll-all-loops -fopenmp -O3 -DNDEBUG
#CUDA compiler:      /usr/local/cuda/bin/nvcc nvcc: NVIDIA (R) Cuda compiler driver;Copyright (c) 2005-2021 NVIDIA Corporation;Built on Wed_Jul_14_19:41:19_PDT_2021;Cuda compilation tools, release 11.4, V11.4.100;Build cuda_11.4.r11.4/compiler.30188945_0
#CUDA compiler flags:-std=c++14;-gencode;arch=compute_35,code=sm_35;-use_fast_math;;-mavx -Wno-missing-field-initializers -fexcess-precision=fast -funroll-all-loops -fopenmp -O3 -DNDEBUG
#CUDA driver:        10.10
#CUDA runtime:       N/A

# Execute pdb2gmx following command to generate topology of trimeric Spike protein, selecting option 15 (OPLS-AA/L)
# Consider protonations described in the main text for each Spike variant

gmx pdb2gmx -f *.model.pdb -his -o protein_processed.gro

# Define the box using editconf

gmx editconf -f protein_processed.gro -o newbox.gro -bt triclinic -d 1.0

# Box solvation using solvate:

gmx solvate -cp newbox.gro -cs spc216.gro -p topol.top -o solv.gro

# Generate an atomic-level description of our system ions.tpr (binary file) using grompp module:

gmx grompp -f ions.mdp -c solv.gro -p topol.top -o ions.tpr -maxwarn 5

# Add ions into water box using genion

gmx genion -s ions.tpr -o solv_ions.gro -p topol.top -pname NA -nname CL -neutral -conc 0.150

# Energy Minimization invoking grompp module and afer mdrun to perform energy minimization step:

gmx grompp -f em.mdp -c solv_ions.gro -p topol.top -o em.tpr -maxwarn 5

gmx mdrun -v -ntmpi 0 -deffnm em

# Perform an NVT ensemble (constant Number of particles, Volume, and Temperature), known as "isothermal-isochoric" or "canonical ensemble.
# NVT equilibration is critical to stabilize system temperature

gmx grompp -f nvt.mdp -c em.gro -r em.gro -p topol.top -o nvt.tpr

gmx mdrun -v -ntmpi 0 -deffnm nvt -pin on


# stabilize the pressure of the system by an NPT ensemble (Number of particles, Pressure, and Temperature, all constants). 
# Known as "isothermal-isobaric" ensemble, in which is considered close to experimental conditions

gmx grompp -f npt.mdp -c nvt.gro -t nvt.cpt -r nvt.gro -p topol.top -o npt.tpr -maxwarn 1

gmx mdrun -v -ntmpi 0 -deffnm npt -pin on

# Molecular dynamics run

gmx grompp -f md.mdp -c npt.gro -t npt.cpt -p topol.top -o md.tpr -maxwarn 1

gmx mdrun -v -ntmpi -deffnm md -pin on


# Processing molecular dynamics data

# use trjconv to account for any periodicity in the system
# Build index.ndx file containing insights about chains A, B and C separately, considering number of corresponding residues

# Delta variant

gmx make_ndx -f md.tpr -o index.ndx

# Chain A of Protein
1 & ri 1-1133

# Chain B of Protein
1 & ri 1134-2266

# Chain C of Protein
1 & ri 2267-3399

# Chain A backbone of Protein
4 & ri 1-1133

# Chain B backbone of Protein
4 & ri 1134-2266

# Chain C backbone of Protein
4 & ri 2267-3399

# Exit with:
q

#remove periodic condition, selecting corresponding Chain A backbone as reference 

gmx trjconv -s md.tpr -f md.xtc -n index.ndx -o md_center.xtc -center -pbc mol -ur compact

# select protein frame from molecular dynamics trajectory, example in time t = 0 ns 

gmx trjconv -s md.tpr -f md_center_fit.xtc -o md_t-0ns.pdb -dump 0

# perform least-squares fitting to protein backbone and choose protein to output 

gmx trjconv -s md.tpr -n index.ndx  -f md_center.xtc -o md_center_fit.xtc -fit rot+trans
