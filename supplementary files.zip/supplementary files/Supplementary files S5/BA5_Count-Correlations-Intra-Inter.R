# Reading the file BA5_correlation_all.csv without labels in the first row and first column
matrix <- read.csv("BA5_correlation_all.csv", header = FALSE)

# Checking if the matrix contains strings and converting them to real numbers if necessary
if (any(sapply(matrix, is.character))) {
  matrix <- apply(matrix, 2, function(x) as.numeric(as.character(x)))
}

n <- 1129

# Splitting the columns into equal parts
col_A <- matrix[, 1:n]
col_B <- matrix[, (n + 1):(n + n)]
col_C <- matrix[, (n + n + 1):(n + n + n)]

# Splitting the rows into equal parts
row_A <- matrix[1:n, ]
row_B <- matrix[(n + 1):(n + n), ]
row_C <- matrix[(n + n + 1):(n + n + n), ]

# Intra-matrices
mat_A_A <- matrix[1:n, 1:n]
mat_B_B <- matrix[(n + 1):(n + n), (n + 1):(n + n)]
mat_C_C <- matrix[(n + n + 1):(n + n + n), (n + n + 1):(n + n + n)]

# Inter-matrices
mat_A_B <- matrix[1:n, (n + 1):(n + n)]
mat_A_C <- matrix[1:n, (n + n + 1):(n + n + n)]
mat_B_C <- matrix[(n + 1):(n + n), (n + n + 1):(n + n + n)]


# Function to calculate the absolute frequency of values less than -0.6 in a matrix, ignoring NA values
calcFreqAbs <- function(mat) {
  freq <- sum(!is.na(mat) & mat < -0.6)
  return(freq)
}

# Calculation of the absolute frequency for each matrix
freq_A_A <- calcFreqAbs(mat_A_A)
freq_B_B <- calcFreqAbs(mat_B_B)
freq_C_C <- calcFreqAbs(mat_C_C)
freq_A_B <- calcFreqAbs(mat_A_B)
freq_A_C <- calcFreqAbs(mat_A_C)
freq_B_C <- calcFreqAbs(mat_B_C)

# Printing the absolute frequencies
cat("Absolute frequency of values less than -0.6:\n")
cat("Protomers A-A:", freq_A_A, "\n")
cat("Protomers B-B:", freq_B_B, "\n")
cat("Protomers C-C:", freq_C_C, "\n")
cat("Protomers A-B:", freq_A_B, "\n")
cat("Protomers A-C:", freq_A_C, "\n")
cat("Protomers B-C:", freq_B_C, "\n")


# Function to calculate the absolute frequency of values greater than 0.6 in a matrix, ignoring NA values
calcFreqAbs <- function(mat) {
  freq <- sum(!is.na(mat) & mat > 0.6)
  return(freq)
}

# Calculation of the absolute frequency for each matrix
freq_A_A <- calcFreqAbs(mat_A_A)
freq_B_B <- calcFreqAbs(mat_B_B)
freq_C_C <- calcFreqAbs(mat_C_C)
freq_A_B <- calcFreqAbs(mat_A_B)
freq_A_C <- calcFreqAbs(mat_A_C)
freq_B_C <- calcFreqAbs(mat_B_C)

# Printing the absolute frequencies
cat("Absolute frequency of values greater than 0.6:\n")
cat("Protomers A-A:", freq_A_A, "\n")
cat("Protomers B-B:", freq_B_B, "\n")
cat("Protomers C-C:", freq_C_C, "\n")
cat("Protomers A-B:", freq_A_B, "\n")
cat("Protomers A-C:", freq_A_C, "\n")
cat("Protomers B-C:", freq_B_C, "\n")

