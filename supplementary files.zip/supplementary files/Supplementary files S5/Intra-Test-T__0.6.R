# Intraprotomer correlations > 0.6
Delta <- c(55386, 50969, 48063)
BA.2 <-  c(51721, 67405, 68733)
BA.5 <-  c(49923, 69901, 47411)
BQ.1 <-  c(36952, 32150, 35870)

# Performing comparisons and printing the results
compare_measures <- function(data1, data2) {
  result <- t.test(data1, data2, conf.level = 0.95)
  p_value <- result$p.value
  conclusion <- ifelse(p_value < 0.1, "Different", "Equal")
  print(paste("Comparison between measures:", deparse(substitute(data1)), "and", deparse(substitute(data2))))
  print(paste("P-value:", p_value))
  print(paste("Conclusion:", conclusion))
  cat("\n")
}

# Comparison between all measures
compare_measures(Delta, BA.2)
compare_measures(Delta, BA.5)
compare_measures(Delta, BQ.1)
compare_measures(BA.2, BA.5)
compare_measures(BA.2, BQ.1)
compare_measures(BA.5, BQ.1)

