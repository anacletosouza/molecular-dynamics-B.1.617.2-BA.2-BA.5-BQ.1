# Data
strain <- c("WT", "Delta", "BA.1", "BA.2", "BA.5", "BQ.1")
corr_intra <- c(51674, 51473, 54029, 62620, 55745, 34991)
anti_corr_intra <- c(4747, 591, 434, 413, 437, 58)
corr_CV_intra <- c(32, 7.2, 14, 15.1, 22.1, 7.2)
anti_corr_CV_intra <- c(102, 99.2, 121, 98.1, 137.8, 93.1)
corr_inter <- c(5157, 1656, 1509, 1922, 3389, 478)
anti_corr_inter <- c(2180, 406, 1169, 1257, 1950, 33)
corr_CV_inter <- c(80, 82, 34, 37, 47.5, 25.7)
anti_corr_CV_inter <- c(66, 79.9, 112, 8.7, 126.6, 93.9)
IC50_ng_mL <- c(372, 800, 1500, 2707, 1088, 7640)

# Standardized data
data <- data.frame(corr_intra, anti_corr_intra, corr_CV_intra, anti_corr_CV_intra, corr_inter, anti_corr_inter, corr_CV_inter, anti_corr_CV_inter, IC50_ng_mL)

# Function to fit a simple linear regression model
fit_lm <- function(vars) {
  formula <- as.formula(paste("IC50_ng_mL ~", paste(vars, collapse = "+")))
  lm_model <- lm(formula, data = data)
  return(lm_model)
}

# Generate all combinations of independent variables
independent_vars <- names(data)[1:8]
combinations <- unlist(lapply(1:length(independent_vars), function(x) combn(independent_vars, x, simplify = FALSE)), recursive = FALSE)

# Fit regression models for each combination
models <- lapply(combinations, fit_lm)

# Print the models
for (i in 1:length(models)) {
  model_formula <- as.character(formula(models[[i]]))
  model_summary <- summary(models[[i]])
  cat("Model", i, ":", model_formula, "\n")
  print(model_summary)
  cat("\n")
}

