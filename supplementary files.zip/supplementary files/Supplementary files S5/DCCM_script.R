library(bio3d)

dcd <- read.dcd("md.dcd")
pdb <- read.pdb("md.pdb")

ca.inds <- atom.select(pdb, elety="CA")
xyz <- fit.xyz(fixed=pdb$xyz, mobile=dcd, fixed.inds=ca.inds$xyz, mobile.inds=ca.inds$xyz)

dim(xyz) == dim(dcd)

cij<-dccm(xyz[,ca.inds$xyz])

cij.all <- filter.dccm(cij, cutoff.cij = 0.6)

pymol.dccm(cij.all, pdb, type="session")

